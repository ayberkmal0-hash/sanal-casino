SANAL GAME CENTER V2
GitHub Pages:
1) index.html dosyasını GitHub repository'ne yükle.
2) Settings > Pages > Deploy from a branch.
3) Branch: main, Folder: / (root), Save.
Oyunlar yalnızca sanal kredi kullanır; gerçek para özelliği yoktur.
